export class CompanyInfo{
  public email: string;
  public address: string;
  public tell: string;

}
